$(document).ready(function() {
	const href = window.location.href;
	const url = new URL(href);
	const query = url.searchParams.get('q');
	const ref = url.searchParams.get('ref');
});
